﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DTO
{
    public class Table
    {
        
        private int soLuongCay;
        private string name;
        private int iD;
        private int dienTich;
        private int iDLoaiCay;
        private string ghiChu;

        public int ID { get => iD; set => iD = value; }
        public string Name { get => name; set => name = value; }
        public int SoLuongCay { get => soLuongCay; set => soLuongCay = value; }
        public int DienTich { get => dienTich; set => dienTich = value; }
        public int IDLoaiCay { get => iDLoaiCay; set => iDLoaiCay = value; }
        public string GhiChu { get => ghiChu; set => ghiChu = value; }

        public Table(int id, string ten, int soluongcay, int dientich, int idloaicay, string ghichu)
        {
            this.ID = id;
            this.Name = ten;
            this.SoLuongCay = soluongcay;
            this.DienTich = dientich;
            this.IDLoaiCay = idloaicay;
            this.GhiChu = ghichu;
        }

        public Table(DataRow row)
        {
            this.ID = (int)row["id"];
            this.Name = row["ten"].ToString();
            this.SoLuongCay = (int)row["soluongcay"];
            this.DienTich = (int)row["dientich"];
            this.IDLoaiCay = (int)row["idloaicay"];
            this.GhiChu = row["ghichu"].ToString();
        }
    }
}
