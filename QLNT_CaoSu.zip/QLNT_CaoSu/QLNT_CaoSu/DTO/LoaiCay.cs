﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DTO
{
    public class LoaiCay
    {
        private int iD;
        private string ten;
        public LoaiCay(int id, string ten)
        {
            this.ID = id;
            this.Ten = ten;
        }
        public LoaiCay(DataRow row)
        {
            this.ID = (int)row["id"];
            this.Ten = row["ten"].ToString();
        }

        public int ID { get => iD; set => iD = value; }
        public string Ten { get => ten; set => ten = value; }
    }
}
