﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DTO
{
    class CongNhan
    {
        public CongNhan(int id, string ho, string ten, DateTime? birth, bool gender)
        {
            this.ID = id;
            this.Ho = ho;
            this.Ten = ten;
            this.Birth = birth;
            this.Gender = gender;

        }

        public CongNhan(DataRow row)
        {
            this.ID = (int)row["id"];
            this.Ho = row["ho"].ToString();
            this.Ten = row["ten"].ToString();
            this.Birth = (DateTime?)row["birth"];
            this.Gender = (bool)row["gender"];

        }


        private int iD;
        private string ho;
        private string ten;
        private DateTime? birth;
        private bool gender;


        public int ID { get => iD; set => iD = value; }
        public string Ho { get => ho; set => ho = value; }
        public string Ten { get => ten; set => ten = value; }
        public DateTime? Birth { get => birth; set => birth = value; }
        public bool Gender { get => gender; set => gender = value; }
    }
}
