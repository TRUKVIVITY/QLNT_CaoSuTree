﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DTO
{
    public class ChamSoc
    {
        private int iD;
        private string ten;
        private int iDPhanKhu;
        private float khoiLuong;
        private float tieuTon;
        private DateTime? ngay;
        //private float tieuTonLuong;
        private string ghiChu;

        public ChamSoc(int iD, string ten, int iDPhanKhu, float khoiLuong, float tieuTon, DateTime? ngay, /*float tieuTonLuong,*/ string ghiChu)
        {
            this.ID = iD;
            this.Ten = ten;
            this.IDPhanKhu = iDPhanKhu;
            this.KhoiLuong = khoiLuong;
            this.TieuTon = tieuTon;
            this.Ngay = ngay;
            //this.TieuTonLuong = tieuTonLuong;
            this.GhiChu = ghiChu;
        }

        public ChamSoc(DataRow row)
        {
            this.ID =(int)row[" iD"];
            this.Ten = row["ten"].ToString();
            this.IDPhanKhu =(int)row["iDPhanKhu"];
            this.KhoiLuong = (float)row["khoiluong"];
            this.TieuTon = (float)row["tieuton"];
            this.Ngay = (DateTime?)row["gia"];
            //this.TieuTonLuong = (float)row["tieutonluong"];
            this.GhiChu = row["ghichu"].ToString();
        }

        public int ID { get => iD; set => iD = value; }
        public string Ten { get => ten; set => ten = value; }
        public int IDPhanKhu { get => iDPhanKhu; set => iDPhanKhu = value; }
        public float KhoiLuong { get => khoiLuong; set => khoiLuong = value; }
        public float TieuTon { get => tieuTon; set => tieuTon = value; }
        public DateTime? Ngay { get => ngay; set => ngay = value; }
        //public float TieuTonLuong { get => tieuTonLuong; set => tieuTonLuong = value; }
        public string GhiChu { get => ghiChu; set => ghiChu = value; }
    }
}
