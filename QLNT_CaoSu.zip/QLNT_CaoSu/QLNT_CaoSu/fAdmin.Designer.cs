﻿namespace QLNT_CaoSu
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnViewThongKe = new System.Windows.Forms.Button();
            this.dtpkToDate = new System.Windows.Forms.DateTimePicker();
            this.dtpkFromDate = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvThongKe = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txbSearchCongNhan = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnThemCN = new System.Windows.Forms.Button();
            this.btnXoaCN = new System.Windows.Forms.Button();
            this.btnSuaCN = new System.Windows.Forms.Button();
            this.panel5l = new System.Windows.Forms.Panel();
            this.dgvCongNhan = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txbGenderCN = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txbBirthCN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.mtxbBirth = new System.Windows.Forms.MaskedTextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txbTenCN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txbHoCN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbIDCongNhan = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel22 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btnCapNhatLg = new System.Windows.Forms.Button();
            this.btnThemLg = new System.Windows.Forms.Button();
            this.btnXoaLg = new System.Windows.Forms.Button();
            this.btnSuaLg = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.dgvLuong = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txbTienLg = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txbNgayLuong = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.txbIDcongNhanLg = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txbIDLuong = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txbGhiChuPhanKhu = new System.Windows.Forms.TextBox();
            this.dgvPhanKhuOrLoaiCay = new System.Windows.Forms.DataGridView();
            this.panel15 = new System.Windows.Forms.Panel();
            this.btnUpdatePK = new System.Windows.Forms.Button();
            this.btnThemPK = new System.Windows.Forms.Button();
            this.btnXoaPK = new System.Windows.Forms.Button();
            this.btnSuaPK = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txbSearchPK = new System.Windows.Forms.TextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.IDLoaiCayPK = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.txpSoLuongCayPK = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.txbDienTichPK = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txbTenphankhu = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txbIDphankhu = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.btnCapNhapCay = new System.Windows.Forms.Button();
            this.btnXoaCay = new System.Windows.Forms.Button();
            this.btnSuaCay = new System.Windows.Forms.Button();
            this.btnThemCay = new System.Windows.Forms.Button();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txbIDLoaiCay = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txbTenLoaiCay = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel31 = new System.Windows.Forms.Panel();
            this.dtgvTaiKhoan = new System.Windows.Forms.DataGridView();
            this.panel30 = new System.Windows.Forms.Panel();
            this.btnUpTK = new System.Windows.Forms.Button();
            this.btnThemTK = new System.Windows.Forms.Button();
            this.btnXoaTK = new System.Windows.Forms.Button();
            this.btnSuaTK = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txbAccountType = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.btnRePass = new System.Windows.Forms.Button();
            this.txbPassword = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.txbDisplayName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.txbUserName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongKe)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5l.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCongNhan)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhanKhuOrLoaiCay)).BeginInit();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel33.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).BeginInit();
            this.panel30.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(-1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(727, 430);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(719, 404);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Thống Kê";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnViewThongKe);
            this.panel3.Controls.Add(this.dtpkToDate);
            this.panel3.Controls.Add(this.dtpkFromDate);
            this.panel3.Location = new System.Drawing.Point(0, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(719, 38);
            this.panel3.TabIndex = 2;
            // 
            // btnViewThongKe
            // 
            this.btnViewThongKe.Location = new System.Drawing.Point(421, 6);
            this.btnViewThongKe.Name = "btnViewThongKe";
            this.btnViewThongKe.Size = new System.Drawing.Size(75, 25);
            this.btnViewThongKe.TabIndex = 2;
            this.btnViewThongKe.Text = "Thống Kê";
            this.btnViewThongKe.UseVisualStyleBackColor = true;
            this.btnViewThongKe.Click += new System.EventHandler(this.btnViewThongKe_Click);
            // 
            // dtpkToDate
            // 
            this.dtpkToDate.Location = new System.Drawing.Point(512, 10);
            this.dtpkToDate.Name = "dtpkToDate";
            this.dtpkToDate.Size = new System.Drawing.Size(200, 20);
            this.dtpkToDate.TabIndex = 1;
            // 
            // dtpkFromDate
            // 
            this.dtpkFromDate.Location = new System.Drawing.Point(204, 10);
            this.dtpkFromDate.Name = "dtpkFromDate";
            this.dtpkFromDate.Size = new System.Drawing.Size(200, 20);
            this.dtpkFromDate.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(3, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(198, 351);
            this.panel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvThongKe);
            this.panel1.Location = new System.Drawing.Point(204, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(515, 354);
            this.panel1.TabIndex = 0;
            // 
            // dgvThongKe
            // 
            this.dgvThongKe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThongKe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongKe.Location = new System.Drawing.Point(3, 3);
            this.dgvThongKe.Name = "dgvThongKe";
            this.dgvThongKe.Size = new System.Drawing.Size(507, 348);
            this.dgvThongKe.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel7);
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Controls.Add(this.panel5l);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(719, 404);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Quản Lý Công Nhân";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txbSearchCongNhan);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(323, 37);
            this.panel7.TabIndex = 0;
            // 
            // txbSearchCongNhan
            // 
            this.txbSearchCongNhan.Location = new System.Drawing.Point(9, 6);
            this.txbSearchCongNhan.Multiline = true;
            this.txbSearchCongNhan.Name = "txbSearchCongNhan";
            this.txbSearchCongNhan.Size = new System.Drawing.Size(233, 25);
            this.txbSearchCongNhan.TabIndex = 6;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(245, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 37);
            this.button5.TabIndex = 5;
            this.button5.Text = "Search";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.btnThemCN);
            this.panel6.Controls.Add(this.btnXoaCN);
            this.panel6.Controls.Add(this.btnSuaCN);
            this.panel6.Location = new System.Drawing.Point(5, 348);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(323, 50);
            this.panel6.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(243, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 39);
            this.button1.TabIndex = 2;
            this.button1.Text = "Cập Nhật";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnThemCN
            // 
            this.btnThemCN.Location = new System.Drawing.Point(3, 8);
            this.btnThemCN.Name = "btnThemCN";
            this.btnThemCN.Size = new System.Drawing.Size(75, 39);
            this.btnThemCN.TabIndex = 3;
            this.btnThemCN.Text = "Thêm";
            this.btnThemCN.UseVisualStyleBackColor = true;
            this.btnThemCN.Click += new System.EventHandler(this.btnThemCN_Click);
            // 
            // btnXoaCN
            // 
            this.btnXoaCN.Location = new System.Drawing.Point(162, 8);
            this.btnXoaCN.Name = "btnXoaCN";
            this.btnXoaCN.Size = new System.Drawing.Size(75, 39);
            this.btnXoaCN.TabIndex = 4;
            this.btnXoaCN.Text = "Xóa";
            this.btnXoaCN.UseVisualStyleBackColor = true;
            this.btnXoaCN.Click += new System.EventHandler(this.btnXoaCN_Click);
            // 
            // btnSuaCN
            // 
            this.btnSuaCN.Location = new System.Drawing.Point(84, 8);
            this.btnSuaCN.Name = "btnSuaCN";
            this.btnSuaCN.Size = new System.Drawing.Size(75, 39);
            this.btnSuaCN.TabIndex = 3;
            this.btnSuaCN.Text = "Sửa";
            this.btnSuaCN.UseVisualStyleBackColor = true;
            this.btnSuaCN.Click += new System.EventHandler(this.btnSuaCN_Click);
            // 
            // panel5l
            // 
            this.panel5l.Controls.Add(this.dgvCongNhan);
            this.panel5l.Location = new System.Drawing.Point(332, 6);
            this.panel5l.Name = "panel5l";
            this.panel5l.Size = new System.Drawing.Size(384, 392);
            this.panel5l.TabIndex = 1;
            // 
            // dgvCongNhan
            // 
            this.dgvCongNhan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCongNhan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCongNhan.Location = new System.Drawing.Point(3, 3);
            this.dgvCongNhan.Name = "dgvCongNhan";
            this.dgvCongNhan.Size = new System.Drawing.Size(384, 389);
            this.dgvCongNhan.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel12);
            this.panel4.Controls.Add(this.panel11);
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Location = new System.Drawing.Point(0, 43);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(323, 304);
            this.panel4.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.txbGenderCN);
            this.panel12.Controls.Add(this.label5);
            this.panel12.Location = new System.Drawing.Point(7, 198);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(313, 42);
            this.panel12.TabIndex = 5;
            // 
            // txbGenderCN
            // 
            this.txbGenderCN.Location = new System.Drawing.Point(118, 8);
            this.txbGenderCN.Name = "txbGenderCN";
            this.txbGenderCN.Size = new System.Drawing.Size(192, 20);
            this.txbGenderCN.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "GIỚI TÍNH : NAM? ";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.txbBirthCN);
            this.panel11.Controls.Add(this.label4);
            this.panel11.Controls.Add(this.mtxbBirth);
            this.panel11.Location = new System.Drawing.Point(7, 150);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(313, 42);
            this.panel11.TabIndex = 4;
            // 
            // txbBirthCN
            // 
            this.txbBirthCN.Enabled = false;
            this.txbBirthCN.Location = new System.Drawing.Point(78, 8);
            this.txbBirthCN.Name = "txbBirthCN";
            this.txbBirthCN.Size = new System.Drawing.Size(109, 20);
            this.txbBirthCN.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "NGÀY SINH";
            // 
            // mtxbBirth
            // 
            this.mtxbBirth.Location = new System.Drawing.Point(192, 8);
            this.mtxbBirth.Name = "mtxbBirth";
            this.mtxbBirth.Size = new System.Drawing.Size(116, 20);
            this.mtxbBirth.TabIndex = 6;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txbTenCN);
            this.panel10.Controls.Add(this.label3);
            this.panel10.Location = new System.Drawing.Point(6, 102);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(313, 42);
            this.panel10.TabIndex = 3;
            // 
            // txbTenCN
            // 
            this.txbTenCN.Location = new System.Drawing.Point(79, 8);
            this.txbTenCN.Name = "txbTenCN";
            this.txbTenCN.Size = new System.Drawing.Size(231, 20);
            this.txbTenCN.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "TÊN: ";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txbHoCN);
            this.panel9.Controls.Add(this.label2);
            this.panel9.Location = new System.Drawing.Point(5, 54);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(313, 42);
            this.panel9.TabIndex = 2;
            // 
            // txbHoCN
            // 
            this.txbHoCN.Location = new System.Drawing.Point(79, 8);
            this.txbHoCN.Name = "txbHoCN";
            this.txbHoCN.Size = new System.Drawing.Size(231, 20);
            this.txbHoCN.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "HỌ: ";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txbIDCongNhan);
            this.panel8.Controls.Add(this.label1);
            this.panel8.Location = new System.Drawing.Point(5, 6);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(313, 42);
            this.panel8.TabIndex = 2;
            // 
            // txbIDCongNhan
            // 
            this.txbIDCongNhan.Location = new System.Drawing.Point(79, 8);
            this.txbIDCongNhan.Name = "txbIDCongNhan";
            this.txbIDCongNhan.Size = new System.Drawing.Size(231, 20);
            this.txbIDCongNhan.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID: ";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel22);
            this.tabPage3.Controls.Add(this.panel21);
            this.tabPage3.Controls.Add(this.panel20);
            this.tabPage3.Controls.Add(this.panel5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(719, 404);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Lương";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.textBox13);
            this.panel22.Controls.Add(this.button10);
            this.panel22.Location = new System.Drawing.Point(6, 6);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(323, 37);
            this.panel22.TabIndex = 4;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(9, 6);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(233, 25);
            this.textBox13.TabIndex = 6;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(245, 0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 37);
            this.button10.TabIndex = 5;
            this.button10.Text = "Search";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.btnCapNhatLg);
            this.panel21.Controls.Add(this.btnThemLg);
            this.panel21.Controls.Add(this.btnXoaLg);
            this.panel21.Controls.Add(this.btnSuaLg);
            this.panel21.Location = new System.Drawing.Point(6, 348);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(323, 50);
            this.panel21.TabIndex = 3;
            // 
            // btnCapNhatLg
            // 
            this.btnCapNhatLg.Location = new System.Drawing.Point(243, 8);
            this.btnCapNhatLg.Name = "btnCapNhatLg";
            this.btnCapNhatLg.Size = new System.Drawing.Size(75, 39);
            this.btnCapNhatLg.TabIndex = 2;
            this.btnCapNhatLg.Text = "Cập Nhật";
            this.btnCapNhatLg.UseVisualStyleBackColor = true;
            this.btnCapNhatLg.Click += new System.EventHandler(this.btnCapNhatLg_Click);
            // 
            // btnThemLg
            // 
            this.btnThemLg.Location = new System.Drawing.Point(3, 8);
            this.btnThemLg.Name = "btnThemLg";
            this.btnThemLg.Size = new System.Drawing.Size(75, 39);
            this.btnThemLg.TabIndex = 3;
            this.btnThemLg.Text = "Thêm";
            this.btnThemLg.UseVisualStyleBackColor = true;
            this.btnThemLg.Click += new System.EventHandler(this.btnThemLg_Click);
            // 
            // btnXoaLg
            // 
            this.btnXoaLg.Location = new System.Drawing.Point(162, 8);
            this.btnXoaLg.Name = "btnXoaLg";
            this.btnXoaLg.Size = new System.Drawing.Size(75, 39);
            this.btnXoaLg.TabIndex = 4;
            this.btnXoaLg.Text = "Xóa";
            this.btnXoaLg.UseVisualStyleBackColor = true;
            this.btnXoaLg.Click += new System.EventHandler(this.btnXoaLg_Click);
            // 
            // btnSuaLg
            // 
            this.btnSuaLg.Location = new System.Drawing.Point(84, 8);
            this.btnSuaLg.Name = "btnSuaLg";
            this.btnSuaLg.Size = new System.Drawing.Size(75, 39);
            this.btnSuaLg.TabIndex = 3;
            this.btnSuaLg.Text = "Sửa";
            this.btnSuaLg.UseVisualStyleBackColor = true;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.dgvLuong);
            this.panel20.Location = new System.Drawing.Point(332, 6);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(387, 392);
            this.panel20.TabIndex = 2;
            // 
            // dgvLuong
            // 
            this.dgvLuong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLuong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLuong.Location = new System.Drawing.Point(3, 3);
            this.dgvLuong.Name = "dgvLuong";
            this.dgvLuong.Size = new System.Drawing.Size(381, 385);
            this.dgvLuong.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel16);
            this.panel5.Controls.Add(this.panel17);
            this.panel5.Controls.Add(this.panel18);
            this.panel5.Controls.Add(this.panel19);
            this.panel5.Location = new System.Drawing.Point(6, 49);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(323, 286);
            this.panel5.TabIndex = 1;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txbTienLg);
            this.panel16.Controls.Add(this.label9);
            this.panel16.Location = new System.Drawing.Point(7, 150);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(313, 42);
            this.panel16.TabIndex = 4;
            // 
            // txbTienLg
            // 
            this.txbTienLg.Location = new System.Drawing.Point(100, 8);
            this.txbTienLg.Name = "txbTienLg";
            this.txbTienLg.Size = new System.Drawing.Size(210, 20);
            this.txbTienLg.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "SỐ TIỀN: ";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.txbNgayLuong);
            this.panel17.Controls.Add(this.label10);
            this.panel17.Location = new System.Drawing.Point(6, 102);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(313, 42);
            this.panel17.TabIndex = 3;
            // 
            // txbNgayLuong
            // 
            this.txbNgayLuong.Location = new System.Drawing.Point(101, 8);
            this.txbNgayLuong.Name = "txbNgayLuong";
            this.txbNgayLuong.Size = new System.Drawing.Size(208, 20);
            this.txbNgayLuong.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "NGÀY: ";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.txbIDcongNhanLg);
            this.panel18.Controls.Add(this.label11);
            this.panel18.Location = new System.Drawing.Point(5, 54);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(313, 42);
            this.panel18.TabIndex = 2;
            // 
            // txbIDcongNhanLg
            // 
            this.txbIDcongNhanLg.Location = new System.Drawing.Point(102, 8);
            this.txbIDcongNhanLg.Name = "txbIDcongNhanLg";
            this.txbIDcongNhanLg.Size = new System.Drawing.Size(208, 20);
            this.txbIDcongNhanLg.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "ID CONG NHAN: ";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.txbIDLuong);
            this.panel19.Controls.Add(this.label12);
            this.panel19.Location = new System.Drawing.Point(5, 6);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(313, 42);
            this.panel19.TabIndex = 2;
            // 
            // txbIDLuong
            // 
            this.txbIDLuong.Location = new System.Drawing.Point(102, 8);
            this.txbIDLuong.Name = "txbIDLuong";
            this.txbIDLuong.Size = new System.Drawing.Size(208, 20);
            this.txbIDLuong.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(4, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "ID: ";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel23);
            this.tabPage4.Controls.Add(this.panel15);
            this.tabPage4.Controls.Add(this.panel14);
            this.tabPage4.Controls.Add(this.tabControl2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(719, 404);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "QL Phân Khu";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.txbGhiChuPhanKhu);
            this.panel23.Controls.Add(this.dgvPhanKhuOrLoaiCay);
            this.panel23.Location = new System.Drawing.Point(329, 6);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(387, 392);
            this.panel23.TabIndex = 7;
            // 
            // txbGhiChuPhanKhu
            // 
            this.txbGhiChuPhanKhu.Location = new System.Drawing.Point(6, 350);
            this.txbGhiChuPhanKhu.Multiline = true;
            this.txbGhiChuPhanKhu.Name = "txbGhiChuPhanKhu";
            this.txbGhiChuPhanKhu.Size = new System.Drawing.Size(378, 38);
            this.txbGhiChuPhanKhu.TabIndex = 9;
            // 
            // dgvPhanKhuOrLoaiCay
            // 
            this.dgvPhanKhuOrLoaiCay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhanKhuOrLoaiCay.Location = new System.Drawing.Point(6, 3);
            this.dgvPhanKhuOrLoaiCay.Name = "dgvPhanKhuOrLoaiCay";
            this.dgvPhanKhuOrLoaiCay.Size = new System.Drawing.Size(378, 341);
            this.dgvPhanKhuOrLoaiCay.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.btnUpdatePK);
            this.panel15.Controls.Add(this.btnThemPK);
            this.panel15.Controls.Add(this.btnXoaPK);
            this.panel15.Controls.Add(this.btnSuaPK);
            this.panel15.Location = new System.Drawing.Point(7, 348);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(319, 50);
            this.panel15.TabIndex = 6;
            // 
            // btnUpdatePK
            // 
            this.btnUpdatePK.Location = new System.Drawing.Point(243, 8);
            this.btnUpdatePK.Name = "btnUpdatePK";
            this.btnUpdatePK.Size = new System.Drawing.Size(75, 39);
            this.btnUpdatePK.TabIndex = 2;
            this.btnUpdatePK.Text = "Cập Nhật";
            this.btnUpdatePK.UseVisualStyleBackColor = true;
            // 
            // btnThemPK
            // 
            this.btnThemPK.Location = new System.Drawing.Point(3, 8);
            this.btnThemPK.Name = "btnThemPK";
            this.btnThemPK.Size = new System.Drawing.Size(75, 39);
            this.btnThemPK.TabIndex = 3;
            this.btnThemPK.Text = "Thêm";
            this.btnThemPK.UseVisualStyleBackColor = true;
            // 
            // btnXoaPK
            // 
            this.btnXoaPK.Location = new System.Drawing.Point(162, 8);
            this.btnXoaPK.Name = "btnXoaPK";
            this.btnXoaPK.Size = new System.Drawing.Size(75, 39);
            this.btnXoaPK.TabIndex = 4;
            this.btnXoaPK.Text = "Xóa";
            this.btnXoaPK.UseVisualStyleBackColor = true;
            // 
            // btnSuaPK
            // 
            this.btnSuaPK.Location = new System.Drawing.Point(84, 8);
            this.btnSuaPK.Name = "btnSuaPK";
            this.btnSuaPK.Size = new System.Drawing.Size(75, 39);
            this.btnSuaPK.TabIndex = 3;
            this.btnSuaPK.Text = "Sửa";
            this.btnSuaPK.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.txbSearchPK);
            this.panel14.Controls.Add(this.button11);
            this.panel14.Location = new System.Drawing.Point(6, 6);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(322, 37);
            this.panel14.TabIndex = 5;
            // 
            // txbSearchPK
            // 
            this.txbSearchPK.Location = new System.Drawing.Point(9, 6);
            this.txbSearchPK.Multiline = true;
            this.txbSearchPK.Name = "txbSearchPK";
            this.txbSearchPK.Size = new System.Drawing.Size(233, 25);
            this.txbSearchPK.TabIndex = 6;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(245, 0);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 37);
            this.button11.TabIndex = 5;
            this.button11.Text = "Search";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Location = new System.Drawing.Point(6, 47);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(323, 290);
            this.tabControl2.TabIndex = 0;
            this.tabControl2.Click += new System.EventHandler(this.tabControl2_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel37);
            this.tabPage6.Controls.Add(this.panel36);
            this.tabPage6.Controls.Add(this.panel35);
            this.tabPage6.Controls.Add(this.panel34);
            this.tabPage6.Controls.Add(this.panel33);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(315, 264);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Phân Khu";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.panel38);
            this.panel37.Controls.Add(this.IDLoaiCayPK);
            this.panel37.Controls.Add(this.label20);
            this.panel37.Location = new System.Drawing.Point(1, 195);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(313, 42);
            this.panel37.TabIndex = 7;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.textBox22);
            this.panel38.Controls.Add(this.label21);
            this.panel38.Location = new System.Drawing.Point(1, 44);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(313, 42);
            this.panel38.TabIndex = 8;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(102, 8);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(208, 20);
            this.textBox22.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(4, 11);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "ID LOẠI CÂY:";
            // 
            // IDLoaiCayPK
            // 
            this.IDLoaiCayPK.Location = new System.Drawing.Point(102, 8);
            this.IDLoaiCayPK.Name = "IDLoaiCayPK";
            this.IDLoaiCayPK.Size = new System.Drawing.Size(208, 20);
            this.IDLoaiCayPK.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(4, 11);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "ID LOẠI CÂY:";
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.txpSoLuongCayPK);
            this.panel36.Controls.Add(this.label19);
            this.panel36.Location = new System.Drawing.Point(0, 147);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(313, 42);
            this.panel36.TabIndex = 6;
            // 
            // txpSoLuongCayPK
            // 
            this.txpSoLuongCayPK.Location = new System.Drawing.Point(102, 8);
            this.txpSoLuongCayPK.Name = "txpSoLuongCayPK";
            this.txpSoLuongCayPK.Size = new System.Drawing.Size(208, 20);
            this.txpSoLuongCayPK.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(4, 11);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "SỐ LƯỢNG CÂY ";
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.txbDienTichPK);
            this.panel35.Controls.Add(this.label18);
            this.panel35.Location = new System.Drawing.Point(1, 99);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(313, 42);
            this.panel35.TabIndex = 5;
            // 
            // txbDienTichPK
            // 
            this.txbDienTichPK.Location = new System.Drawing.Point(102, 8);
            this.txbDienTichPK.Name = "txbDienTichPK";
            this.txbDienTichPK.Size = new System.Drawing.Size(208, 20);
            this.txbDienTichPK.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(4, 11);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "DIỆN TÍCH: ";
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.txbTenphankhu);
            this.panel34.Controls.Add(this.label17);
            this.panel34.Location = new System.Drawing.Point(0, 51);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(313, 42);
            this.panel34.TabIndex = 4;
            // 
            // txbTenphankhu
            // 
            this.txbTenphankhu.Location = new System.Drawing.Point(102, 8);
            this.txbTenphankhu.Name = "txbTenphankhu";
            this.txbTenphankhu.Size = new System.Drawing.Size(208, 20);
            this.txbTenphankhu.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(4, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Tên: ";
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.txbIDphankhu);
            this.panel33.Controls.Add(this.label16);
            this.panel33.Location = new System.Drawing.Point(0, 3);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(313, 42);
            this.panel33.TabIndex = 3;
            // 
            // txbIDphankhu
            // 
            this.txbIDphankhu.Location = new System.Drawing.Point(102, 8);
            this.txbIDphankhu.Name = "txbIDphankhu";
            this.txbIDphankhu.Size = new System.Drawing.Size(208, 20);
            this.txbIDphankhu.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(4, 11);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "ID: ";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.btnCapNhapCay);
            this.tabPage7.Controls.Add(this.btnXoaCay);
            this.tabPage7.Controls.Add(this.btnSuaCay);
            this.tabPage7.Controls.Add(this.btnThemCay);
            this.tabPage7.Controls.Add(this.panel32);
            this.tabPage7.Controls.Add(this.panel26);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(315, 264);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Loại Cây";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // btnCapNhapCay
            // 
            this.btnCapNhapCay.Location = new System.Drawing.Point(237, 28);
            this.btnCapNhapCay.Name = "btnCapNhapCay";
            this.btnCapNhapCay.Size = new System.Drawing.Size(75, 39);
            this.btnCapNhapCay.TabIndex = 5;
            this.btnCapNhapCay.Text = "Cập Nhật";
            this.btnCapNhapCay.UseVisualStyleBackColor = true;
            // 
            // btnXoaCay
            // 
            this.btnXoaCay.Location = new System.Drawing.Point(159, 28);
            this.btnXoaCay.Name = "btnXoaCay";
            this.btnXoaCay.Size = new System.Drawing.Size(75, 39);
            this.btnXoaCay.TabIndex = 5;
            this.btnXoaCay.Text = "Xóa";
            this.btnXoaCay.UseVisualStyleBackColor = true;
            // 
            // btnSuaCay
            // 
            this.btnSuaCay.Location = new System.Drawing.Point(81, 28);
            this.btnSuaCay.Name = "btnSuaCay";
            this.btnSuaCay.Size = new System.Drawing.Size(75, 39);
            this.btnSuaCay.TabIndex = 5;
            this.btnSuaCay.Text = "Sửa";
            this.btnSuaCay.UseVisualStyleBackColor = true;
            // 
            // btnThemCay
            // 
            this.btnThemCay.Location = new System.Drawing.Point(3, 28);
            this.btnThemCay.Name = "btnThemCay";
            this.btnThemCay.Size = new System.Drawing.Size(75, 39);
            this.btnThemCay.TabIndex = 5;
            this.btnThemCay.Text = "Thêm";
            this.btnThemCay.UseVisualStyleBackColor = true;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.txbIDLoaiCay);
            this.panel32.Controls.Add(this.label15);
            this.panel32.Location = new System.Drawing.Point(3, 73);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(313, 42);
            this.panel32.TabIndex = 3;
            // 
            // txbIDLoaiCay
            // 
            this.txbIDLoaiCay.Location = new System.Drawing.Point(102, 8);
            this.txbIDLoaiCay.Name = "txbIDLoaiCay";
            this.txbIDLoaiCay.Size = new System.Drawing.Size(208, 20);
            this.txbIDLoaiCay.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(4, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "ID: ";
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.txbTenLoaiCay);
            this.panel26.Controls.Add(this.label7);
            this.panel26.Location = new System.Drawing.Point(3, 133);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(313, 42);
            this.panel26.TabIndex = 3;
            // 
            // txbTenLoaiCay
            // 
            this.txbTenLoaiCay.Location = new System.Drawing.Point(102, 8);
            this.txbTenLoaiCay.Name = "txbTenLoaiCay";
            this.txbTenLoaiCay.Size = new System.Drawing.Size(208, 20);
            this.txbTenLoaiCay.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(4, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "TÊN LOẠI CÂY: ";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel31);
            this.tabPage5.Controls.Add(this.panel30);
            this.tabPage5.Controls.Add(this.panel25);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(719, 404);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Tài Khoản";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.dtgvTaiKhoan);
            this.panel31.Location = new System.Drawing.Point(330, 6);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(387, 392);
            this.panel31.TabIndex = 8;
            // 
            // dtgvTaiKhoan
            // 
            this.dtgvTaiKhoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvTaiKhoan.Location = new System.Drawing.Point(6, 3);
            this.dtgvTaiKhoan.Name = "dtgvTaiKhoan";
            this.dtgvTaiKhoan.Size = new System.Drawing.Size(378, 381);
            this.dtgvTaiKhoan.TabIndex = 0;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.btnUpTK);
            this.panel30.Controls.Add(this.btnThemTK);
            this.panel30.Controls.Add(this.btnXoaTK);
            this.panel30.Controls.Add(this.btnSuaTK);
            this.panel30.Location = new System.Drawing.Point(6, 348);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(323, 50);
            this.panel30.TabIndex = 7;
            // 
            // btnUpTK
            // 
            this.btnUpTK.Location = new System.Drawing.Point(243, 8);
            this.btnUpTK.Name = "btnUpTK";
            this.btnUpTK.Size = new System.Drawing.Size(75, 39);
            this.btnUpTK.TabIndex = 2;
            this.btnUpTK.Text = "Cập Nhật";
            this.btnUpTK.UseVisualStyleBackColor = true;
            this.btnUpTK.Click += new System.EventHandler(this.btnUpTK_Click);
            // 
            // btnThemTK
            // 
            this.btnThemTK.Location = new System.Drawing.Point(3, 8);
            this.btnThemTK.Name = "btnThemTK";
            this.btnThemTK.Size = new System.Drawing.Size(75, 39);
            this.btnThemTK.TabIndex = 3;
            this.btnThemTK.Text = "Thêm";
            this.btnThemTK.UseVisualStyleBackColor = true;
            this.btnThemTK.Click += new System.EventHandler(this.btnThemTK_Click);
            // 
            // btnXoaTK
            // 
            this.btnXoaTK.Location = new System.Drawing.Point(162, 8);
            this.btnXoaTK.Name = "btnXoaTK";
            this.btnXoaTK.Size = new System.Drawing.Size(75, 39);
            this.btnXoaTK.TabIndex = 4;
            this.btnXoaTK.Text = "Xóa";
            this.btnXoaTK.UseVisualStyleBackColor = true;
            this.btnXoaTK.Click += new System.EventHandler(this.btnXoaTK_Click);
            // 
            // btnSuaTK
            // 
            this.btnSuaTK.Location = new System.Drawing.Point(84, 8);
            this.btnSuaTK.Name = "btnSuaTK";
            this.btnSuaTK.Size = new System.Drawing.Size(75, 39);
            this.btnSuaTK.TabIndex = 3;
            this.btnSuaTK.Text = "Sửa";
            this.btnSuaTK.UseVisualStyleBackColor = true;
            this.btnSuaTK.Click += new System.EventHandler(this.btnSuaTK_Click);
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.panel13);
            this.panel25.Controls.Add(this.panel27);
            this.panel25.Controls.Add(this.panel28);
            this.panel25.Controls.Add(this.panel29);
            this.panel25.Location = new System.Drawing.Point(6, 49);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(323, 286);
            this.panel25.TabIndex = 6;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.txbAccountType);
            this.panel13.Controls.Add(this.label6);
            this.panel13.Location = new System.Drawing.Point(5, 150);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(313, 42);
            this.panel13.TabIndex = 4;
            // 
            // txbAccountType
            // 
            this.txbAccountType.Location = new System.Drawing.Point(112, 8);
            this.txbAccountType.Name = "txbAccountType";
            this.txbAccountType.Size = new System.Drawing.Size(197, 20);
            this.txbAccountType.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "TYPE: ";
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.btnRePass);
            this.panel27.Controls.Add(this.txbPassword);
            this.panel27.Controls.Add(this.label8);
            this.panel27.Location = new System.Drawing.Point(6, 102);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(313, 42);
            this.panel27.TabIndex = 3;
            // 
            // btnRePass
            // 
            this.btnRePass.Location = new System.Drawing.Point(211, 8);
            this.btnRePass.Name = "btnRePass";
            this.btnRePass.Size = new System.Drawing.Size(97, 20);
            this.btnRePass.TabIndex = 5;
            this.btnRePass.Text = "reset Pass";
            this.btnRePass.UseVisualStyleBackColor = true;
            this.btnRePass.Click += new System.EventHandler(this.btnRePass_Click);
            // 
            // txbPassword
            // 
            this.txbPassword.Location = new System.Drawing.Point(112, 8);
            this.txbPassword.Name = "txbPassword";
            this.txbPassword.Size = new System.Drawing.Size(93, 20);
            this.txbPassword.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "MẬT KHẨU: ";
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.txbDisplayName);
            this.panel28.Controls.Add(this.label13);
            this.panel28.Location = new System.Drawing.Point(5, 54);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(313, 42);
            this.panel28.TabIndex = 2;
            // 
            // txbDisplayName
            // 
            this.txbDisplayName.Location = new System.Drawing.Point(113, 8);
            this.txbDisplayName.Name = "txbDisplayName";
            this.txbDisplayName.Size = new System.Drawing.Size(197, 20);
            this.txbDisplayName.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "TÊN HIỂN THỊ: ";
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.txbUserName);
            this.panel29.Controls.Add(this.label14);
            this.panel29.Location = new System.Drawing.Point(5, 6);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(313, 42);
            this.panel29.TabIndex = 2;
            // 
            // txbUserName
            // 
            this.txbUserName.Location = new System.Drawing.Point(113, 8);
            this.txbUserName.Name = "txbUserName";
            this.txbUserName.Size = new System.Drawing.Size(197, 20);
            this.txbUserName.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(1, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "TÊN ĐĂNG NHẬP: ";
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 430);
            this.Controls.Add(this.tabControl1);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fAdmin";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongKe)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel5l.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCongNhan)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhanKhuOrLoaiCay)).EndInit();
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTaiKhoan)).EndInit();
            this.panel30.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnViewThongKe;
        private System.Windows.Forms.DateTimePicker dtpkToDate;
        private System.Windows.Forms.DateTimePicker dtpkFromDate;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnXoaCN;
        private System.Windows.Forms.Button btnThemCN;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel5l;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSuaCN;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dgvCongNhan;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txbSearchCongNhan;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txbGenderCN;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txbBirthCN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txbTenCN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txbHoCN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txbIDCongNhan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btnCapNhatLg;
        private System.Windows.Forms.Button btnThemLg;
        private System.Windows.Forms.Button btnXoaLg;
        private System.Windows.Forms.Button btnSuaLg;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.DataGridView dgvLuong;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txbTienLg;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txbNgayLuong;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox txbIDcongNhanLg;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txbIDLuong;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.DataGridView dgvPhanKhuOrLoaiCay;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button btnUpdatePK;
        private System.Windows.Forms.Button btnThemPK;
        private System.Windows.Forms.Button btnXoaPK;
        private System.Windows.Forms.Button btnSuaPK;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txbSearchPK;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dgvThongKe;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.DataGridView dtgvTaiKhoan;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Button btnUpTK;
        private System.Windows.Forms.Button btnThemTK;
        private System.Windows.Forms.Button btnXoaTK;
        private System.Windows.Forms.Button btnSuaTK;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.TextBox txbPassword;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.TextBox txbDisplayName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.TextBox txbUserName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TextBox IDLoaiCayPK;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.TextBox txpSoLuongCayPK;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.TextBox txbDienTichPK;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.TextBox txbTenphankhu;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TextBox txbIDphankhu;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txbIDLoaiCay;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox txbTenLoaiCay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txbGhiChuPhanKhu;
        private System.Windows.Forms.Button btnCapNhapCay;
        private System.Windows.Forms.Button btnXoaCay;
        private System.Windows.Forms.Button btnSuaCay;
        private System.Windows.Forms.Button btnThemCay;
        private System.Windows.Forms.MaskedTextBox mtxbBirth;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txbAccountType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRePass;
    }
}