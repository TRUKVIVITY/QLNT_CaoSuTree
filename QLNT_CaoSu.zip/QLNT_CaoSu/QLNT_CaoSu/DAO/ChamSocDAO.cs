﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DAO
{
    class ChamSocDAO
    {
        private static ChamSocDAO instance;

        internal static ChamSocDAO Instance { get{ if (instance == null) instance = new ChamSocDAO(); return instance; } private set => instance = value; }
        private ChamSocDAO() { }

    }

    
}
