﻿using QLNT_CaoSu.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DAO
{
    class CongNhanDAO
    {
        private static CongNhanDAO instance;

        internal static CongNhanDAO Instance
        {
            get { if (instance == null) instance = new CongNhanDAO(); return instance; }
            private set => instance = value;
        }
        private CongNhanDAO() { }

        public List<CongNhan> GetListCongNhan()
            {
                List<CongNhan> list = new List<CongNhan>();
                string query = "SELECT * FROM CongNhan";
                DataTable data = DataProvider.Instance.ExecuteQuery(query);
                foreach(DataRow item in data.Rows)
                {
                    CongNhan congNhan = new CongNhan(item);
                    list.Add(congNhan);
                }
                return list;
            }

        public bool InsertCongNhan(string ho, string ten, DateTime? birth, int gender)
        {
            string query = "INSERT INTO dbo.CongNhan(ho, ten, birth, gender)VALUES(N'" + ho + "', N'" + ten + "', '" + birth + "'," + gender + " )";
            int result = DataProvider.Instance.ExecuteNonQuery(query);
            // ExecuteNonQuery truy vấn rồi trả ra trường dữ liệu kiểu int, số dòng thêm vào thành công

            return result > 0;
        }

        public bool UpdateCongNhan(int id, string ho, string ten, DateTime? birth, int gender)
        {
            string query = String.Format("UPDATE dbo.CongNhan SET ho =N'{0}', ten =N'{1}', birth ='{2}', gender ={3} WHERE id = {4}", ho, ten, birth, gender, id);
            int result = DataProvider.Instance.ExecuteNonQuery(query);
            // ExecuteNonQuery truy vấn rồi trả ra trường dữ liệu kiểu int, số dòng thêm vào thành công

            return result > 0;
        }

        public bool CheckCongNhan(int id)
        {
            string query = "SELECT * from dbo.CongNhan WHERE id = "+id;
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            // ExecuteNonQuery truy vấn rồi trả ra trường dữ liệu kiểu int, số dòng thêm vào thành công
            // vì câu truy vấn trả về kiểu table nên ko dùng được ExecuteNonQuery;
            return result.Rows.Count > 0;
        }

        //dek biết dùng như tn?
        public CongNhan GetNameByIdCongNhan(string id)
        {
            string query = "SELECT ho,ten from dbo.CongNhan WHERE id = " + id;
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            

            foreach (DataRow item in result.Rows)
            {
                return new CongNhan(item);
            }

            return null;

        }

        public bool DeleteCongNhan(int id)
        {
            string query = String.Format("DELETE dbo.CongNhan WHERE id = " + id);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
    }
}
    

    
//}
