﻿using QLNT_CaoSu.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DAO
{
    class LuongDAO
    {
        private static LuongDAO instance;

        public static LuongDAO Instance { get{ if (instance == null) instance = new LuongDAO(); return instance; } private set => instance = value; }
        private LuongDAO() { }

        public List<Luong> GetListLuong()
        {
            List<Luong> list = new List<Luong>();
            string query = "select * from Luong";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                Luong luong = new Luong(item);
                list.Add(luong);
            }
            return list;
        }

        public bool InsertLuong(int idcongnhan, DateTime? ngay, Double? sotien)
        {
            string query = string.Format("INSERT INTO dbo.Luong(idcongnhan,ngay,sotien)VALUES({0},'{1}',{2})",idcongnhan,ngay,sotien);
            int result = DataProvider.Instance.ExecuteNonQuery(query);
            // ExecuteNonQuery truy vấn rồi trả ra trường dữ liệu kiểu int, số dòng thêm vào thành công

            return result > 0;
        }

        public bool DeleteLuong(int id)
        {
            string query = String.Format("DELETE dbo.Luong WHERE id = " + id);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

    }
}
