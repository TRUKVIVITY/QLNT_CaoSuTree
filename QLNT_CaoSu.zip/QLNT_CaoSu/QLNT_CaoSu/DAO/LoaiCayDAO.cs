﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DAO
{
    class LoaiCayDAO
    {
        private static LoaiCayDAO instance;

        internal static LoaiCayDAO Instance { get { if (instance == null) instance = new LoaiCayDAO(); return instance; } set => instance = value; }
        private LoaiCayDAO() { }


    }
}
