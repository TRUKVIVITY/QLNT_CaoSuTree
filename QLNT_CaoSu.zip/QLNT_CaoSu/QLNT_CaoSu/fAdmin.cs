﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using QLNT_CaoSu.DAO;
using System.Text.RegularExpressions;
using QLNT_CaoSu.DTO;

namespace QLNT_CaoSu
{
    public partial class fAdmin : Form
    {
        BindingSource BindingCongNhan = new BindingSource();
        BindingSource BindingLuong = new BindingSource();
        BindingSource accountList = new BindingSource();
        private Account loginAccount;

        public Account LoginAccount { get => loginAccount; set => loginAccount = value; }

        public fAdmin()
        {
            InitializeComponent();

            LoadAccountList(); //use void LoadAccountList();
            Load();
        }
        void Load()
        {
            dgvThongKe.DataSource = SanLuongDAO.Instance.GetListSanLuong();
            dgvCongNhan.DataSource = BindingCongNhan;
            LoadListCongNhan();
            AddCongNhanBinding();
            //
            dgvLuong.DataSource = BindingLuong;
            LoadListLuong();
            AddLuongBinding();
            //
            dtgvTaiKhoan.DataSource = accountList;
            LoadAccountList();
            AddAccountBinding();
            //if()
            mtxbBirth.Mask = "00/00/0000";
            mtxbBirth.KeyUp += new KeyEventHandler(CheckDate);
            string.Format("MM/dd/yyyy", mtxbBirth);

        }

        #region Method

        void AddAccountBinding()
        {
            txbUserName.DataBindings.Add(new Binding("Text", dtgvTaiKhoan.DataSource, "UserName", true, DataSourceUpdateMode.Never));
            txbDisplayName.DataBindings.Add(new Binding("Text", dtgvTaiKhoan.DataSource, "DisplayName", true, DataSourceUpdateMode.Never));
            txbAccountType.DataBindings.Add(new Binding("Text", dtgvTaiKhoan.DataSource, "Type", true, DataSourceUpdateMode.Never));
        }

        void LoadAccountList()
        {
            //string query = "EXEC dbo.USP_GetAccountByUserName @userName";

            //dtgvTaiKhoan.DataSource = DataProvider.Instance.ExecuteQuery(query, new object[] { "Rumi", "staff" });
            accountList.DataSource = AccountDAO.Instance.GetListAccount();

        }
        void LoadListLuong()
        {
            BindingLuong.DataSource = LuongDAO.Instance.GetListLuong();
        }

        void AddLuongBinding()
        {
            txbIDLuong.DataBindings.Add("Text", dgvLuong.DataSource,"id", true, DataSourceUpdateMode.Never);
            txbIDcongNhanLg.DataBindings.Add("Text", dgvLuong.DataSource, "idcongnhan", true, DataSourceUpdateMode.Never);
            txbNgayLuong.DataBindings.Add("Text", dgvLuong.DataSource, "ngay", true, DataSourceUpdateMode.Never);
            txbTienLg.DataBindings.Add("Text", dgvLuong.DataSource, "sotien", true, DataSourceUpdateMode.Never);
        }

        void LoadListCongNhan()
        {
            BindingCongNhan.DataSource = CongNhanDAO.Instance.GetListCongNhan();
        }

        void AddCongNhanBinding()
        {
            //Thuộc tính của "Text" sẽ thay đổi theo "ten" dựa vào cái DataSource(nguồn), true : chấp nhận ép kiểu tự động
            //giữa 2 bên dữ liệu và DataSourceUpdateMode.Never là dữ liệu đi 1 luồng duy nhất qua Binding
            txbTenCN.DataBindings.Add("Text", dgvCongNhan.DataSource, "Ten", true, DataSourceUpdateMode.Never);

            txbHoCN.DataBindings.Add("Text", dgvCongNhan.DataSource, "Ho", true, DataSourceUpdateMode.Never);
            txbIDCongNhan.DataBindings.Add("Text", dgvCongNhan.DataSource, "ID", true, DataSourceUpdateMode.Never);
            txbBirthCN.DataBindings.Add("Text", dgvCongNhan.DataSource, "Birth", true, DataSourceUpdateMode.Never);
            txbGenderCN.DataBindings.Add("Text", dgvCongNhan.DataSource, "Gender", true, DataSourceUpdateMode.Never);
        }
        void LoadListPhanKhu()
        {
            //if(tabControl2.SelectedIndexChanged ==)
        }

        void CheckDate(Object sender, KeyEventArgs e)
        {
            if (mtxbBirth.MaskFull)
            {
                try
                {
                    DateTime.ParseExact(mtxbBirth.Text, "MM/dd/yyyy", null);
                }
                catch
                {
                    MessageBox.Show("Ngày hay Tháng không tồn tại","Ngày không hợp lệ");
                    mtxbBirth.ResetText();
                }
            }
        }

        void AddAccount(string userName, string displayName, int type)
        {
            if (AccountDAO.Instance.InsertAccount(userName, displayName, type))
            {
                MessageBox.Show("Thêm tài khoản thành công");
            }
            else
            {
                MessageBox.Show("Thêm tài khoản thất bại");
            }

            LoadAccountList();
        }

        void EditAccount(string userName, string displayName, int type)
        {
            if (AccountDAO.Instance.UpdateAccount(userName, displayName, type))
            {
                MessageBox.Show("Cập nhật tài khoản thành công");
            }
            else
            {
                MessageBox.Show("Cập nhật tài khoản thất bại");
            }

            LoadAccountList();
        }

        void DeleteAccount(string userName)
        {
            if (LoginAccount.UserName.Equals(userName))
            {
                MessageBox.Show("Tài khoản hiện đang được dùng");
                return;
            }
            if (AccountDAO.Instance.DeleteAccount(userName))
            {
                MessageBox.Show("Xóa tài khoản thành công");
            }
            else
            {
                MessageBox.Show("Xóa tài khoản thất bại");
            }

            LoadAccountList();
        }

        void ResetPass(string userName)
        {
            if (AccountDAO.Instance.ResetPassword(userName))
            {
                MessageBox.Show("Đặt lại mật khẩu thành công");
            }
            else
            {
                MessageBox.Show("Đặt lại mật khẩu thất bại");
            }
        }

        #endregion

        #region Event
        private void button1_Click(object sender, EventArgs e)
        {
            LoadListCongNhan();
        }

        private void btnThemCN_Click(object sender, EventArgs e)
        {
            //int id = Convert.ToInt16(txbIDCongNhan.Text);
            string ho = txbHoCN.Text;
            string ten = txbTenCN.Text;
            string dateTimeString = mtxbBirth.Text;
            DateTime dateValue = default(DateTime);

            //string.Format("{0:MMMM dd, yyyy}", birth);// format kiểu ngày tháng thành: May 21, 2018// để thử nhưng cảm thấy vô dung vcl

            if ((txbGenderCN.Text == "1" || txbGenderCN.Text == "0") && DateTime.TryParse(dateTimeString, out dateValue))
            {
                int gender = Convert.ToInt16(txbGenderCN.Text);
                DateTime? birth = Convert.ToDateTime(dateTimeString);

                if (CongNhanDAO.Instance.InsertCongNhan(ho, ten, birth, gender))
                {
                    MessageBox.Show("Thêm Công Nhân Mới Thành Công");
                    LoadListCongNhan();
                }
                else
                {
                    MessageBox.Show("Lỗi Thêm Công Nhân");
                }
            }
            else
            {
                MessageBox.Show("Ngày không tồn tại?\nNam nhập: 1\nNữ    nhập: 0", "Lỗi Ngày Or Lỗi Giới Tính!");
            }
        }



        private void btnSuaCN_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt16(txbIDCongNhan.Text);
            string ho = txbHoCN.Text;
            string ten = txbTenCN.Text;
            //if(mtxbBirth.TextLength == 7)
            //{
            //    DateTime? birth = Convert.ToDateTime(mtxbBirth.Text);
            //}
            //else
            //{
            //    MessageBox.Show("Vui lòng sửa lại ngày tháng năm!");
            //}
            DateTime dateValue = default(DateTime);
            string dateTimeString = mtxbBirth.Text;

            if ((txbGenderCN.Text == "1" || txbGenderCN.Text == "0") && DateTime.TryParse(dateTimeString, out dateValue))
            {
                int gender = Convert.ToInt16(txbGenderCN.Text);
                DateTime? birth = Convert.ToDateTime(dateTimeString);

                if (CongNhanDAO.Instance.UpdateCongNhan(id, ho, ten, birth, gender))
                {
                    MessageBox.Show("Thây đổi Thông Tin Công Nhân Mới Thành Công!");
                    LoadListCongNhan();
                }
                else
                {
                    MessageBox.Show("Lỗi Không Sửa Được Thoomg Tin Công Nhân!");
                }
            }
            else
            {
                MessageBox.Show("Ngày không tồn tại?\nNam nhập: 1\nNữ    nhập: 0", "Lỗi Ngày Or Lỗi Giới Tính!");
            }
        }
        

        void demo()
        {
            
        }

        private void tabControl2_Click(object sender, EventArgs e)
        {
            if(tabControl2.SelectedTab == tabPage7)
            {
                MessageBox.Show("Come");
                btnThemPK.Enabled = false;
                btnSuaPK.Enabled = false;
                btnXoaPK.Enabled = false;
                btnUpdatePK.Enabled = false;
                txbGhiChuPhanKhu.Enabled = false;
                
            }
            else if (tabControl2.SelectedTab == tabPage6)
            {
                btnThemPK.Enabled = true;
                btnSuaPK.Enabled = true;
                btnXoaPK.Enabled = true;
                btnUpdatePK.Enabled = true;
                txbGhiChuPhanKhu.Enabled = true;
            }
        }

        private void btnCapNhatLg_Click(object sender, EventArgs e)
        {
            LoadListLuong();
        }

        private void btnThemLg_Click(object sender, EventArgs e)
        {
            try
            {
                //int idluong = Convert.ToInt16(txbIDLuong.Text);
                int idCongNhan = Convert.ToInt16(txbIDcongNhanLg.Text);
                DateTime? Ngay = Convert.ToDateTime(txbNgayLuong.Text);
                Double? Sotien = Convert.ToDouble(txbTienLg.Text);
                if (LuongDAO.Instance.InsertLuong(idCongNhan, Ngay, Sotien))
                {
                    MessageBox.Show("Success");
                }
                else
                {
                    MessageBox.Show("ERR: Insert");
                }
            }catch
            {
                MessageBox.Show("ERR:");
            }
        }

        private void btnXoaLg_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt16(txbIDLuong.Text);
                if (LuongDAO.Instance.DeleteLuong(id))
                {
                    MessageBox.Show("Lương đã được xóa!");
                    LoadListLuong();
                }
                else
                {
                    MessageBox.Show("Xóa Lỗi");
                    LoadListLuong();
                }
            }
            catch { MessageBox.Show("lỗi định dạng dữ liệu!"); }
        }

        private void btnXoaCN_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt16(txbIDCongNhan.Text);
                if (MessageBox.Show("Bạn có thực sự muốn xóa nhân viên này? \nSản Lượng mà Nhân viên này sẽ bị xóa theo!", "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                {
                    if (SanLuongDAO.Instance.DeleteSanLuongCongNhan(id))
                    {
                        if (CongNhanDAO.Instance.DeleteCongNhan(id)) MessageBox.Show("Xóa Công Nhân thành công!"); LoadListCongNhan();
                    }
                    else { MessageBox.Show("Extra ERR"); }

                }
            }
            catch { MessageBox.Show("App này nó bệnh con mẹ nó rồi!"); }
        }

        private void btnThemTK_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;
            string displayName = txbDisplayName.Text;
            
            if (txbAccountType.Text == "1" || txbAccountType.Text == "0")
            {
                int type = Convert.ToInt16(txbAccountType.Text); ;
                
                AddAccount(userName, displayName, type);
            }
            else { MessageBox.Show("Admin type: 1\n Staff type: 0"); }
            
        }

        private void btnSuaTK_Click(object sender, EventArgs e)
        {
            
            string userName = txbUserName.Text;
            string displayName = txbDisplayName.Text;
            if (txbAccountType.Text == "1" || txbAccountType.Text == "0")
            {
                int type = Convert.ToInt16(txbAccountType.Text); ;
                EditAccount(userName, displayName, type);
            }
            else { MessageBox.Show("Admin type: 1\n Staff type: 0"); }
            

            
        }

        private void btnXoaTK_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;

            DeleteAccount(userName);
        }

        private void btnUpTK_Click(object sender, EventArgs e)
        {
            LoadAccountList();
        }

        private void btnRePass_Click(object sender, EventArgs e)
        {
            string userName = txbUserName.Text;

            ResetPass(userName);
        }

        //
        #endregion

        private void btnViewThongKe_Click(object sender, EventArgs e)
        {
            try
            {
                Thongke(dtpkFromDate.Value, dtpkToDate.Value);
            }
            catch { }
        }
        private void Thongke(DateTime d, DateTime d2)
        {
            dgvThongKe.DataSource = SanLuongDAO.Instance.GetListSanLuongFromDate(d, d2);
        }
    }
}
