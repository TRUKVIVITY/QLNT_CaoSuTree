﻿using QLNT_CaoSu.DAO;
using QLNT_CaoSu.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLNT_CaoSu
{
    public partial class fManager : Form
    {
        BindingSource BindingSanLuong = new BindingSource();
        private Account loginAccount;

        public Account LoginAccount { get => loginAccount; set { loginAccount = value; ChangeAccount(loginAccount.Type);} }

        public fManager(Account acc)
        {
            InitializeComponent();
            this.LoginAccount = acc;

            LoadTable();
            dtgvSanLuong.DataSource = BindingSanLuong;
            LoadSanLuong();
            AddSanLuongBinding();
            
        }
        #region Method

        void ChangeAccount(int type)
        {
            adminToolStripMenuItem.Enabled = type == 1;
            thôngTinTàiKhoảnToolStripMenuItem.Text += " (" + LoginAccount.DisplayName + ")";
        }

        void LoadTable()
        {
            List<Table> tableList = TableDAO.Instance.LoadTableList();

            foreach (Table item in tableList)
            {
                Button btn = new Button() { Width = TableDAO.TableWidth, Height = TableDAO.TableHeight };
                btn.Text ="ID = " + item.ID +Environment.NewLine + item.Name + Environment.NewLine + item.SoLuongCay + " Cây";

                switch (item.ID %2)
                {
                    case 0:
                        btn.BackColor = Color.LightBlue;
                        break;
                    default:
                        btn.BackColor = Color.LightGreen;
                        break;
                }

                flpManager.Controls.Add(btn);
            }
        }

        void LoadSanLuong()
        {
            BindingSanLuong.DataSource = SanLuongDAO.Instance.GetListSanLuong();
            btnThem.Text = "TẠO MỚI";
            btnSua.Enabled = true;
            btnXoa.Enabled = true;
        }

        void AddSanLuongBinding()
        {
            txbIDSanLuong.DataBindings.Add("Text", dtgvSanLuong.DataSource, "id", true, DataSourceUpdateMode.Never);
            txbDateTime.DataBindings.Add("Text", dtgvSanLuong.DataSource, "ngay", true, DataSourceUpdateMode.Never);
            txbKhoiLuong.DataBindings.Add("Text", dtgvSanLuong.DataSource, "khoiluong", true, DataSourceUpdateMode.Never);
            txbMaCongNhan.DataBindings.Add("Text", dtgvSanLuong.DataSource, "idcongnhan", true, DataSourceUpdateMode.Never);
            txbMaPhanKhu.DataBindings.Add("Text", dtgvSanLuong.DataSource, "idphankhu", true, DataSourceUpdateMode.Never);
        }

        //demo return ERR
        void CheckInt(string CImpk, string CImcn, string CIcid, string CIkg)
        {
            if (!int.TryParse(txbMaPhanKhu.Text, out parsedValue))
            {
                MessageBox.Show("MaPhanKhu is a number only field");
                txbMaPhanKhu.ResetText();
                return;
            }
            if (!int.TryParse(txbMaCongNhan.Text, out parsedValue))
            {
                MessageBox.Show("Ma Cong Nhan is a number only field");
                txbMaCongNhan.ResetText();
                return;
            }
            if (!int.TryParse(txbIDSanLuong.Text, out parsedValue))
            {
                MessageBox.Show("ID San Luong is a number only field");
                txbIDSanLuong.ResetText();
                return;
            }
            if (!int.TryParse(txbKhoiLuong.Text, out parsedValue))
            {
                MessageBox.Show("Khoi Luong a number only field");
                txbKhoiLuong.ResetText();
                return;
            }
            else
            {
                CImpk = txbMaPhanKhu.Text;
                CImcn = txbMaCongNhan.Text;
                CIcid = txbIDSanLuong.Text;
                CIkg = txbKhoiLuong.Text;

            }
        }
        void LoadNameCNByID()
        {
            //Load tên công nhân trên txbTenCongNhan khi txbIDcongnhan khớp dữ liệu
        }

        #endregion

        #region Event
        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin fad = new fAdmin();
            fad.ShowDialog();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tàiKhoảnCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAccountProfile facc = new fAccountProfile(LoginAccount);
            facc.UpdateAccount += facc_UpdateAccount;
            facc.ShowDialog();
        }

        void facc_UpdateAccount(object sender, AccountEvent e)
        {
            thôngTinTàiKhoảnToolStripMenuItem.Text = "Thông tin tài khoản (" + e.Acc.DisplayName + ")";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            LoadSanLuong();
        }
        DateTime dateValue = default(DateTime);
        private static string dateString =null;
        int parsedValue;

        private void btnSua_Click(object sender, EventArgs e)
        {

            dateString = txbDateTime.Text;
            string mpk = null;
            string mcn = null;
            string cid = null;
            string kg = null;
            //CheckInt(mpk, mcn, cid, kg);
            //Check dữ liệu nhập vào text phải là kiểu int;
            // form sau làm mẹ cái thư viện bool cho khỏe~
            if (!int.TryParse(txbMaPhanKhu.Text, out parsedValue))
            {
                MessageBox.Show("MaPhanKhu is a number only field");
                txbMaPhanKhu.ResetText();
                return;
            }
            if (!int.TryParse(txbMaCongNhan.Text, out parsedValue))
            {
                MessageBox.Show("Ma Cong Nhan is a number only field");
                txbMaCongNhan.ResetText();
                return;
            }
            if (!int.TryParse(txbIDSanLuong.Text, out parsedValue))
            {
                MessageBox.Show("ID San Luong is a number only field");
                txbIDSanLuong.ResetText();
                return;
            }
            if (!int.TryParse(txbKhoiLuong.Text, out parsedValue))
            {
                MessageBox.Show("Khoi Luong a number only field");
                txbKhoiLuong.ResetText();
                return;
            }
            else
            {
                mpk = txbMaPhanKhu.Text;
                mcn = txbMaCongNhan.Text;
                cid = txbIDSanLuong.Text;
                kg = txbKhoiLuong.Text;
                
            }

            int idPhanKhu = Convert.ToInt16(mpk);
            int idCongNhan = Convert.ToInt16(mcn);
            int khoiLuong = Convert.ToInt16(kg);
            int id = Convert.ToInt16(cid);

            if(DateTime.TryParse(dateString, out dateValue))
            {
                //check ngày tháng năm nhập vào trước khi biến date tiến hành Convert!
                DateTime? date = Convert.ToDateTime(dateString);

                if (SanLuongDAO.Instance.UpdateSanLuong(id,idPhanKhu,idCongNhan,date,khoiLuong))
                {
                    MessageBox.Show("Sửa đổi thành công");
                    LoadSanLuong();
                }
                else
                {
                    MessageBox.Show("ERR: Sửa đổi không  thành công");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập lại ngày tháng năm!", "Lỗi Ngày Tháng Năm");
            }
            
        }

        
        //hàm trung gian để trả về true false cho CongNhanDAO.Instance.CheckCongNhan;
        bool CheckCongNhan(int id)
        {
            return CongNhanDAO.Instance.CheckCongNhan(id);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (btnThem.Text == "TẠO MỚI")
            {
                btnThem.Text = "THÊM MỚI";
                txbIDSanLuong.Enabled = false;
                txbIDSanLuong.Text = "Mã Sản Lượng Tăng tự động";

                txbKhoiLuong.ResetText();
                txbMaCongNhan.ResetText();
                //set ngày hiện tại vào textbox
                txbDateTime.Text = DateTime.Now.Date.ToShortDateString();

                btnSua.Enabled = false;
                btnXoa.Enabled = false;
            }
            else if(btnThem.Text == "THÊM MỚI")
            {
                dateString = txbDateTime.Text;
                string mpk = null;
                string mcn = null;
                string kg = null;
                try
                {
                    if (!int.TryParse(txbMaPhanKhu.Text, out parsedValue))
                    {
                        MessageBox.Show("MaPhanKhu is a number only field");
                        txbMaPhanKhu.ResetText();
                        return;
                    }
                    if (!int.TryParse(txbMaCongNhan.Text, out parsedValue))
                    {
                        MessageBox.Show("Ma Cong Nhan is a number only field");
                        txbMaCongNhan.ResetText();
                        return;
                    }
                    if (!int.TryParse(txbKhoiLuong.Text, out parsedValue))
                    {
                        MessageBox.Show("Khoi Luong a number only field");
                        txbKhoiLuong.ResetText();
                        return;
                    }

                    else
                    {
                        mpk = txbMaPhanKhu.Text;
                        kg = txbKhoiLuong.Text;

                        if (CheckCongNhan(Convert.ToInt16(txbMaCongNhan.Text)))
                        {
                            mcn = txbMaCongNhan.Text;
                        }
                        else
                        {
                            MessageBox.Show("Mã Công Nhân", " specified cast is not valid");
                            txbMaCongNhan.ResetText();
                            return;
                        }

                    }

                    int idPhanKhu = Convert.ToInt16(mpk);
                    int idCongNhan = Convert.ToInt16(mcn);
                    int khoiLuong = Convert.ToInt32(kg);

                    if (DateTime.TryParse(dateString, out dateValue))
                    {
                        //check ngày tháng năm nhập vào trước khi biến date tiến hành Convert!
                        DateTime? date = Convert.ToDateTime(dateString);

                        if (SanLuongDAO.Instance.InsertSanLuong(idPhanKhu, idCongNhan, date, khoiLuong))
                        {
                            MessageBox.Show("Thêm mới thành công");
                            LoadSanLuong();
                            btnThem.Text = "TẠO MỚI";
                            btnSua.Enabled = true;
                            btnXoa.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("ERR: Thêm mới không  thành công");
                            btnThem.Text = "TẠO MỚI";
                            btnSua.Enabled = true;
                            btnXoa.Enabled = true;

                        }
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng nhập lại ngày tháng năm!", "Lỗi Ngày Tháng Năm");
                    }
                }catch
                {
                    MessageBox.Show( " specified cast is not valid");
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int cid;

            if (!int.TryParse(txbIDSanLuong.Text, out parsedValue))
            {
                MessageBox.Show("ID San Luong is a number only field");
                txbIDSanLuong.ResetText();
                return;
            }
            else
            {
                cid = Convert.ToInt16( txbIDSanLuong.Text);
            }
            int id = cid;
            if(SanLuongDAO.Instance.DeleteSanLuong(id))
            {
                MessageBox.Show("Xóa Thành Công");
                LoadSanLuong();
            }
            else
            {
                MessageBox.Show("Invalid object name 'dbo.SanLuong'.");
            }
        }
        #endregion
    }

}
