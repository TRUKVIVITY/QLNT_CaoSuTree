﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DTO
{
    class Luong
    {
        private int iD;
        private int iDCongNhan;
        private DateTime? ngay;
        private Double? soTien;

        public Luong(int id, int idcongnhan, DateTime? ngay, Double? sotien)
        {
            this.ID = id;
            this.IDCongNhan = idcongnhan;
            this.Ngay = ngay;
            this.SoTien = sotien;
        }

        public Luong(DataRow row)
        {
            this.ID = (int)row["id"];
            this.IDCongNhan = (int)row["idcongnhan"];
            this.Ngay = (DateTime?)row["ngay"];
            this.SoTien = Convert.ToDouble(row["sotien"]);
        }

        public int ID { get => iD; set => iD = value; }
        public int IDCongNhan { get => iDCongNhan; set => iDCongNhan = value; }
        public DateTime? Ngay { get => ngay; set => ngay = value; }
        public Double? SoTien { get => soTien; set => soTien = value; }
    }
}
