﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DTO
{
    class SanLuong
    {
       

        public SanLuong(int id, int idphankhu, int idnhanvien, DateTime ngay, int khoiluong)
        {
            this.ID = id;
            this.IDPhanKhu = idphankhu;
            this.IDCongNhan = idnhanvien;
            this.Ngay = ngay;
            this.KhoiLuong = khoiLuong;
        }

        public SanLuong(DataRow row)
        {
            this.ID = (int)row["id"];
            this.IDCongNhan = (int)row["idcongnhan"];
            this.IDPhanKhu = (int)row["idphankhu"];
            
            this.Ngay = (DateTime)row["ngay"];
            this.KhoiLuong = (int)row["khoiluong"];
        }

        private int iD;
        private int iDPhanKhu;
        private int iDCongNhan;
        private DateTime ngay;
        private int khoiLuong;

        public int ID { get => iD; set => iD = value; }
        public int IDPhanKhu { get => iDPhanKhu; set => iDPhanKhu = value; }
        public int IDCongNhan { get => iDCongNhan; set => iDCongNhan = value; }
        public DateTime Ngay { get => ngay; set => ngay = value; }
        public int KhoiLuong { get => khoiLuong; set => khoiLuong = value; }
    }
}
