﻿using QLNT_CaoSu.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNT_CaoSu.DAO
{
    class SanLuongDAO
    {
        private static SanLuongDAO instance;

        internal static SanLuongDAO Instance
        {

            get { if (instance == null) instance = new SanLuongDAO(); return instance; }
            private set => instance = value;

        }
        private SanLuongDAO() { }

        public List<SanLuong> GetListSanLuong()
        {
            List<SanLuong> list = new List<SanLuong>();
            string query = "SELECT * FROM SanLuong";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                SanLuong sanLuong = new SanLuong(item);
                list.Add(sanLuong);
            }
            return list;
        }

        public bool UpdateSanLuong(int id, int idphankhu, int idcongnhan, DateTime? ngay, int khoiluong)
        {
            string query = String.Format("UPDATE dbo.SanLuong SET idphankhu ={0}, idcongnhan ={1}, ngay ='{2}', khoiluong ={3} WHERE id = {4}", idphankhu, idcongnhan, ngay, khoiluong, id);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool InsertSanLuong(int idphankhu, int idcongnhan, DateTime? ngay, int khoiluong)
        {
            string query = String.Format("INSERT INTO dbo.SanLuong( idPhanKhu, idCongNhan, Ngay, khoiluong ) VALUES({0},{1},'{2}',{3})", idphankhu, idcongnhan, ngay, khoiluong);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool DeleteSanLuong(int id)
        {
            string query = String.Format("DELETE dbo.SanLuong WHERE id = "+id);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool DeleteSanLuongCongNhan(int id)
        {
            string query = String.Format("DELETE dbo.SanLuong WHERE idcongnhan = " + id);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            // nếu bằng o row thì có nghĩ sản lượng này ko tồn tại và có thể tiến hành xóa công nhân
            //nếu lớn hơn 0 thì row sản lượng đó đã bị xóa!
            return result >= 0;
        }
    }
    
}
